#include "stm32f10x.h"
#include "Human_Body_Infrared_Moudle.h"
#include "LED.h"


int main(void)
{
    LED_Init();//LED初始化(PB4)
		Human_Body_Infrared_Moudle_Init();//人体红外模块初始化(PA1)
    
    while(1)
    {
			if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1) == Bit_SET)//判断人体红外模块是否检测到人
        {
            
            GPIO_WriteBit(GPIOB, GPIO_Pin_4, Bit_SET);//LED 亮
        }
        else
        {
            GPIO_WriteBit(GPIOB, GPIO_Pin_4, Bit_RESET);//LED 灭
        }
    }
}
