#ifndef __HUMAN_BODY_INFRARED_MOUDLE_H__
#define __HUMAN_BODY_INFRARED_MOUDLE_H__

#include "stm32f10x.h"

void Human_Body_Infrared_Moudle_Init(void);//人体红外模块初始化(PA1)

#endif
